package view;

import entity.Manufacturer;
import session.ManufacturerFacadeLocal;

import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@Named(value = "manufacturerManagedBean")
@SessionScoped
public class ManufacturerManagedBean implements Serializable {

    @EJB
    private ManufacturerFacadeLocal manufacturerFacade;

    private Manufacturer selectedManufacturer = new Manufacturer();

    public Manufacturer getSelectedManufacturer() {
        return selectedManufacturer;
    }

    public void setSelectedManufacturer(Manufacturer selectedManufacturer) {
        this.selectedManufacturer = selectedManufacturer;
    }

    // READ: lista todos los fabricantes
    public List<Manufacturer> getManufacturerList() {
        return manufacturerFacade.findAll();
    }

    // CREATE
    public String create() {
        manufacturerFacade.create(selectedManufacturer);
        addMessage("Fabricante creado correctamente.");
        selectedManufacturer = new Manufacturer();
        return "ManufacturerList?faces-redirect=true";
    }

    // Prepara el formulario para editar
    public String prepareEdit(Manufacturer manufacturer) {
        this.selectedManufacturer = manufacturer;
        return "ManufacturerForm?faces-redirect=true";
    }

    // UPDATE
    public String update() {
        manufacturerFacade.edit(selectedManufacturer);
        addMessage("Fabricante actualizado correctamente.");
        selectedManufacturer = new Manufacturer();
        return "ManufacturerList?faces-redirect=true";
    }

    // DELETE
    public String delete(Manufacturer manufacturer) {
        manufacturerFacade.remove(manufacturer);
        addMessage("Fabricante eliminado correctamente.");
        return "ManufacturerList?faces-redirect=true";
    }

    // Prepara un formulario limpio
    public String prepareNew() {
        this.selectedManufacturer = new Manufacturer();
        return "ManufacturerForm?faces-redirect=true";
    }

    private void addMessage(String msg) {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, msg, null));
    }
}