package view;

import entity.Customer;
import session.CustomerFacadeLocal;

import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@Named(value = "customerManagedBean")
@SessionScoped
public class CustomerManagedBean implements Serializable {

    @EJB
    private CustomerFacadeLocal customerFacade;

    // Objeto usado para crear o editar un cliente en el formulario
    private Customer selectedCustomer = new Customer();

    public Customer getSelectedCustomer() {
        return selectedCustomer;
    }

    public void setSelectedCustomer(Customer selectedCustomer) {
        this.selectedCustomer = selectedCustomer;
    }

    // READ: lista todos los clientes
    public List<Customer> getCustomerList() {
        return customerFacade.findAll();
    }

    // CREATE
    public String create() {
        customerFacade.create(selectedCustomer);
        addMessage("Cliente creado correctamente.");
        selectedCustomer = new Customer();
        return "CustomerList?faces-redirect=true";
    }

    // Prepara el formulario para editar un registro existente
    public String prepareEdit(Customer customer) {
        this.selectedCustomer = customer;
        return "CustomerForm?faces-redirect=true";
    }

    // UPDATE
    public String update() {
        customerFacade.edit(selectedCustomer);
        addMessage("Cliente actualizado correctamente.");
        selectedCustomer = new Customer();
        return "CustomerList?faces-redirect=true";
    }

    // DELETE
    public String delete(Customer customer) {
        customerFacade.remove(customer);
        addMessage("Cliente eliminado correctamente.");
        return "CustomerList?faces-redirect=true";
    }

    // Prepara un formulario limpio para "Nuevo Cliente"
    public String prepareNew() {
        this.selectedCustomer = new Customer();
        return "CustomerForm?faces-redirect=true";
    }

    private void addMessage(String msg) {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, msg, null));
    }
}